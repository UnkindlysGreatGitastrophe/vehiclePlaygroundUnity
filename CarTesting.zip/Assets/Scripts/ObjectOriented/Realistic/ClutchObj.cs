using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClutchObj : MonoBehaviour
{
    // Start is called before the first frame update
    [Header("References")]
    public CarObj car;

    [Header("Clutch Lock")]
    public bool toggleManualClutch = false;
    public float clutchLock;


    [Header("Clutch B1 (Connected to Engine)")]
    [SerializeField] private float w1;
    [SerializeField] private float t1;
    [SerializeField] private float i1;

    [Header("Clutch B2 (Connected to DriveShaft)")]
    [SerializeField] private float w2;
    [SerializeField] private float t2;
    [SerializeField] private float i2;

    [Header("Clutch V2 parameters")]

    [SerializeField] private float clutchTorq;
    [SerializeField] private float clutchDampening = 0.7f;
    [SerializeField] private float clutchCapacity = 1.3f;
    [SerializeField] private float clutchStiffness = 40f;
    [SerializeField] private float clutchMaxTorq;


    [Header("Constants")]
    [SerializeField] private float AV_2_RPM = 60 / (2*Mathf.PI);
    [SerializeField] private float RPM_2_AV;

    void Start()
    {
        clutchMaxTorq = clutchStiffness * clutchCapacity;
    }

    public float calculateClutch()
    {
        float engineAngularVelocityToRPM = car.engine.engineAngularVelocity * AV_2_RPM;
        if (toggleManualClutch == false)
        {
            clutchLock = Remap(engineAngularVelocityToRPM, 1000, 1300, 0,1);
            if (car.gearBox.get_ratio() == 0)
            {
                clutchLock = Mathf.Min(1 + clutchLock,1);

            }
            else
            {
                clutchLock = Mathf.Min(clutchLock,1);
            }
        }
        
        w1 = car.engine.engineAngularVelocity; // Engine Angular Velocity
        t1 = car.engine.torque_out; // Engine Torque
        i1 = car.engine.engineMoment; // Engine Flywheel Inertia

        t2 = 0; // Wheel Reaction Torque of all POWERED WHEELS!
        
        for (int i = 0; i < car.poweredWheels.Length; i++)
        {
            t2 += car.poweredWheels[i].ReactionTorqueToWheel / (car.gearBox.get_ratio() * car.driveTrain.differentialFinalGearRatio);
        }
        // DriveTrain Inertia
        i2 = (car.poweredWheels[0].wheelInertia+car.poweredWheels[1].wheelInertia)/Mathf.Pow(car.gearBox.get_ratio() * car.driveTrain.differentialFinalGearRatio,2); // DriveTrain Inertia powered wheels, I2=(wi1+wi2+ ... + wiN)/(gear ratio^2)
        float avgSpin = 0;
        for (int w = 2; w < 4; w++)
        {
            avgSpin += car.wheels[w].wheelAngularVelocity * 0.5f;
        }

        w2 = avgSpin * (car.gearBox.get_ratio() * car.driveTrain.differentialFinalGearRatio); // Drivetrain Angular Velocity


        //return Mathf.Clamp(
        //    (i1 * t2 - i2 * t1 - i1 * i2 * (w1 - w2) / Time.fixedDeltaTime) / (i1 + i2),
        //    -clutchMaxTorq * clutchLock,
        //    clutchMaxTorq * clutchLock);

        return (w1-w2) * clutchLock;
    }

    public static float Remap (float input, float rangeMin, float rangeEnd, float newRangeMin,  float newRangeEnd)
    {
        float t = Mathf.InverseLerp(rangeMin, rangeEnd, input);
        float output = Mathf.Lerp(newRangeMin, newRangeEnd, t);
        return output;
    }

    void Update()
    {
        if (toggleManualClutch)
        {
            if (Input.GetKeyDown(KeyCode.C))
            {
                clutchLock = 0;
            }
            else
            {
                clutchLock = 1;
            }
        }
        
    }
}
