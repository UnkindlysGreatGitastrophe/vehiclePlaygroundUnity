using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using UnityEngine;

public class CarObj : MonoBehaviour
{
    [Header("References")]
    public EngineObj engine;
    public ClutchObj clutch;
    public GearBoxObj gearBox;
    public DriveTrainObj driveTrain;
    public WheelObj[] wheels;
    public WheelObj[] poweredWheels;

    [Header("Input")]
    public float Throttle;
    public bool ThrottleLock;
    public float Brake;
    public float steeringInput;

    [Header("Output")]
    public float Tc = 0; // Torque produced from the clutch after supplying it with the engine Torque
    public float torqueToWheel = 0; // Torque produced from the Gearbox after supplying it with the Torque CLutch
    // Start is called before the first frame update

    // Car Operation begins here:
    void FixedUpdate()
    {
        GetInput();
        steeringInput = Input.GetAxis("Horizontal");
        engine.engineOperation();
        if (gearBox.get_ratio() != 0)
        {
            Tc = clutch.calculateClutch(); // We need to add Reaction Torque to engine via -TC
            //Tc = engine.torque_out;      // Meanwhile, the TC needs to be positive to driveTorque
        }
        else
            Tc = 0;
        //driveTrain.calculateDriveShaft();
        torqueToWheel = Tc * gearBox.get_ratio() * driveTrain.differentialFinalGearRatio / poweredWheels.Length;
        for (int i = 0; i < wheels.Length; i++)
        {
            if (poweredWheels.Contains(wheels[i]))
            {
                wheels[i].applyTorqueToWheels(torqueToWheel);
                wheels[i].applyLongitudinalForce();
            }
            else
            {
                wheels[i].applyTorqueToWheels(0);
                wheels[i].applyLongitudinalForce();
            }
                
        }


    }

    #region Input Handling
    public void GetInput()
    {
            if (Input.GetKeyDown(KeyCode.T))
            {
                ThrottleLock = !ThrottleLock;
            }
            if (ThrottleLock)
            {
                Throttle = 1;
            }
            else
            {
                if (Input.GetAxisRaw("Vertical") == 1)
                {
                    Throttle = Mathf.Clamp(Throttle + Time.fixedDeltaTime * 4, 0, 1);
                }
                else
                {
                    Throttle = Mathf.Clamp(Throttle + Time.fixedDeltaTime * -10, 0, 1);
                }

                if (Input.GetAxisRaw("Vertical") == -1)
                {
                    Brake = Mathf.Lerp(Brake, 1, 8*Time.deltaTime);
                }
                else
                {
                    Brake = Mathf.Lerp(Brake, 0, 16*Time.deltaTime);
                }
            }
            
    }
    #endregion

    
}
