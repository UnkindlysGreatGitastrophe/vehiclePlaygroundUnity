using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BrakeObj : MonoBehaviour
{
    public float brakeTorque;
    // Start is called before the first frame update
    public float calculateBrakeForce(float brakeInput, float brakeBias, float maxBrakeTorque)
    {
        return 0;
    }
}
